from .colors import Color
from .directions import Direction

w = Color.white
b = Color.blue
y = Color.yellow
g = Color.green
o = Color.orange
r = Color.red

right = Direction.right
left = Direction.left
up = Direction.up
down = Direction.down
back = Direction.back