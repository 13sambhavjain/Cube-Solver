from core import Cube3x3
from tests.test_solver3x3 import testFirstCross
from utils.prints2structure import print2Cube3x3
if __name__ == "__main__":
    # k = testFirstCross(numberOfCases=10000, breakAtFirstFail=True)['passes']
    # for scam in k:
    #     c = Cube3x3()
    #     c.apply_moves(scam["scram"])
    #     print(c)
    #     c.apply_moves(scam["moves"])
    #     print(c)
    #     print(f"{len(scam["moves"])}\n\n\n")

        print2Cube3x3("""G O O 
G W W
W W Y

Y B B   G O Y
Y B B   O O Y
W W O   B G G

        R R R   R G G
        R Y Y   R G G
        W B B   O O Y

                R Y W
                R R W
                O B B""")