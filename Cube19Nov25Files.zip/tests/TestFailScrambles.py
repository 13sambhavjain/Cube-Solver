FirstCrossFails = [
    ['red', 'orange`', ('yellow', 'yellow'), 'orange', ('orange', 'orange'), 'green', ('orange', 'orange'), 'yellow', ('yellow', 'yellow'), ('white', 'white')],
    ['green', ('white', 'white'), 'red', ('red', 'red'), ('orange', 'orange'), 'green', 'green`', 'blue', ('red', 'red'), 'blue']
]